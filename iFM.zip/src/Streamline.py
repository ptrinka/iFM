################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

from PhreeqCProblem import PhreeqCProblem
import os
import numpy as np

from LoggerIFM import LoggerIFM
logger = LoggerIFM.getLogger()

class Streamline:
    '''
    This class initializes the actual chemistry for each streamline. 
    
    Each Streamline object will control one PhreeqC DLL instance through PhreeqCProblem
    '''
    def __init__(self, ID, streamLineInfo, aInOutTools, aChemicalInformation, aTimePeriod, aOutput, aTimeStep):
        self.streamLineID = ID
        self.inOutTools = aInOutTools
        self.chemicalInformation = aChemicalInformation
        self.timePeriod = aTimePeriod
        self.output = aOutput
        self.timeStep = aTimeStep
        
        self.radionuclidesInfo = self.chemicalInformation.radionuclidesInfo
        self.numberOfCells = streamLineInfo["numberOfCells"]
        self.tauChemicalDomains = streamLineInfo["tauChemicalDomains"]
        self.timePeriodsGeneralChemistry = streamLineInfo["timePeriodsGeneralChemistry"]
        self.timePeriodsRadionuclids = streamLineInfo["timePeriodsRadionuclids"]
        self.KdFormulation = streamLineInfo["KdFormulation"]
        self.transportOptions = self.chemicalInformation.transportOptions
        
        self.tauMin = -1
        self.tauMax = -1
        self.numBatchCells = -1

        # Create dependant classes
        self.dllPath = os.path.join(os.path.dirname(__file__))
        self.dllLibraryFile = "Iphreeqc.dll"
        phreeqcDLLFile = self.inOutTools.getPathAndFile(self.dllPath, self.dllLibraryFile)
        self.phreeqcProblem = PhreeqCProblem(phreeqcDLLFile, self.chemicalInformation.phreeqcDatabase, self.inOutTools)
        
        # list of times, tau and dict of kds
        self.allKds = {"Kds" : {},
                       "tau" : [],
                       "time": [] 
                      }
        self.useMatrix = False
        self.lastTimePeriodID = None

    def initialize(self, tauMin, tauMax):
        '''
        initialize
        '''
        self.tauMin = tauMin
        self.tauMax = tauMax
        self.deltaTau = (self.tauMax - self.tauMin)/float(self.numberOfCells)
        self.deltaTime = self.deltaTau 
        logger.info("Number of cells: " +  str(self.numberOfCells))
        logger.info("Max(Tau): " +  str(self.tauMax))
        logger.info("Delta Tau: " +  str(self.deltaTau))
        if self.KdFormulation == "ES":
            self.useMatrix = False
        elif self.KdFormulation == "LD":
            self.useMatrix = True
        self.numBatchCells = self.numberOfCells
        self.phreeqcProblem.initialize()
        dbLines = self.chemicalInformation.getExtraPhreeqcDatabaseLines()
        self.phreeqcProblem.loadString(dbLines)


    def calculateInitialConditions(self):
        '''
        For each domain (range of phreeqc cells), get the correct initial conditions and boundary conditions.
        Do 1 phreeqc simulation for the initial value of these cells and set the results in attributes of this class 
        '''
        #load initial water
        for chemDomName, spatialDomain in self.tauChemicalDomains.items():
            spatialDomain = self.chemicalInformation.getSpatialDomain(spatialDomain)
            iniSolution = self.chemicalInformation.getInitialSolution(chemDomName)
            self.phreeqcProblem.loadCellsInfoSolution(spatialDomain, iniSolution)

        #load boundary water
        timePeriodID = self.timePeriod.getPeriodID(self.timePeriodsGeneralChemistry)
        boundarySolution = self.chemicalInformation.getBoundarySolution(timePeriodID)
        boundaryDomain = self.chemicalInformation.getSpatialBoundaryDomain()
        self.phreeqcProblem.loadCellsInfoSolution(boundaryDomain, boundarySolution)

        #load reactions
        for chemDomName, spatialDomain in self.tauChemicalDomains.items():
            spatialDomain = self.chemicalInformation.getSpatialDomain(spatialDomain)
            reactionsSolution = self.chemicalInformation.getReactionsSolution(chemDomName)
            self.phreeqcProblem.loadCellsInfoEquilibrium(spatialDomain, reactionsSolution)

       
        selOutputValues = self.chemicalInformation.getSelOutput()
        KdExprSpecies = self.getKdExprSpecies()
        self.phreeqcProblem.setUpOutput(KdExprSpecies, selOutputValues)

        
        currentTime = self.timeStep.getCurrentTime()
        deltaTime = self.timeStep.getDeltaTime()
        fractureDomain = self.chemicalInformation.getFractureDomain(self.numberOfCells)
        self.phreeqcProblem.runDomain(fractureDomain, currentTime, deltaTime)

        if self.KdFormulation == "LD":
            # copy cells to matrix area
            matrixDomain = self.chemicalInformation.getMatrixDomain(self.numberOfCells)
            self.phreeqcProblem.duplicateCells(fractureDomain, matrixDomain)
            self.phreeqcProblem.runDomain(matrixDomain, currentTime, deltaTime)

        logger.info('Calculated initial conditions')

    def computeBatchReactions(self):
        '''
        Copy the matrix or fracture cells and calculate the batch reactions in each of them.
        '''
        curTime = self.timeStep.getCurrentTime() 
        deltaTime = self.timeStep.getDeltaTime()

        sourceDomain = []
        if self.KdFormulation == "ES":
            sourceDomain = self.chemicalInformation.getActualFractureDomain(self.numberOfCells)
        elif self.KdFormulation == "LD":
            sourceDomain = self.chemicalInformation.getActualMatrixDomain(self.numberOfCells)
        else:
            logger.error("Incorrect Kd formulation chosen: " + self.KdFormulation)
            logger.error("Stopping application.")
            exit()

        batchCellDomain = self.chemicalInformation.getBatchCellsDomain(self.numberOfCells, self.useMatrix)        
        # get radionuclide info
        timePeriodID = self.timePeriod.getPeriodID(self.timePeriodsRadionuclids)
        nuclideSolution = self.chemicalInformation.getNuclideSolution(timePeriodID)
        nuclideReactions = self.chemicalInformation.getNuclideReactions(timePeriodID)

        self.radionuclideValues = self.phreeqcProblem.copyDomainsAndApplyReactions(curTime,
                                                                                   deltaTime,
                                                                                   sourceDomain, 
                                                                                   batchCellDomain,
                                                                                   nuclideSolution,
                                                                                   nuclideReactions)
        
    def computeTransportGeneralChemistryStep(self, timeLogger):
        '''
        Let Phreeqc run a transport step.
        '''
        currentTime = self.timeStep.getPrevTime()
        timePeriodID = self.timePeriod.getPeriodID(self.timePeriodsGeneralChemistry)
        boundarySolution = self.chemicalInformation.getBoundarySolution(timePeriodID)
        deltaTime = self.timeStep.getDeltaTime()
        transportSettingsString = self.chemicalInformation.getTransportSettings()
        self.phreeqcProblem.runTransport(transportSettingsString,
                                         self.transportOptions, 
                                         boundarySolution, 
                                         self.numberOfCells,
                                         currentTime,
                                         deltaTime,
                                         self.useMatrix)
        
    def getDeltaTau(self):
        return self.deltaTau
    
    def getAllTau(self):
        allTau = []
        for i in range(1,self.numberOfCells+1):
            allTau.append(i*self.deltaTau)
        return allTau
    
    def getKdSetID(self):
        timePeriodID = self.timePeriod.getPeriodID(self.timePeriodsRadionuclids)
        KdSetID = self.radionuclidesInfo.getKdSetID(timePeriodID)
        return KdSetID
    
    def getKdExprSpecies(self):
        KdSetID = self.getKdSetID()
        KdExprSpecies = self.radionuclidesInfo.getKdExprSpecies(KdSetID)
        return KdExprSpecies
    
    def getKdExpressions(self):
        KdSetID = self.getKdSetID()
        KdExpressions = self.radionuclidesInfo.getKdExpressions(KdSetID)
        return KdExpressions

    def getKdSpecies(self):
        KdSetID = self.getKdSetID()
        KdExpressions = self.radionuclidesInfo.getKdExpressions(KdSetID)
        KdSpecies = list(KdExpressions)
        return KdSpecies
        
    def getKdExpressionsDetails(self):
        KdSetID = self.getKdSetID()
        KdExpressionDetails = self.radionuclidesInfo.getKdExpressionsDetails(KdSetID)
        return KdExpressionDetails

    def computeKds(self):
        '''
        Copy the matrix or fracture cells and calculate the batch reactions in each of them. 
        Then process the Kd expression that applies to the current period for each of the batch reaction cells
        '''
        self.computeBatchReactions()
        self.KdsValuesTimeStep = self.computeKdsExpressions()
        
    def computeKdsExpressions(self):
        '''
        Evaluate the provided Kd expression. This converts the names of the species to their respective concentrations. 
        '''
        _u = self.radionuclideValues
        allKdValues = []
        KdExpressions = self.getKdExpressionsDetails()
        for _cell in range(0, self.numBatchCells):
            expressions = KdExpressions["expressions"]
            exprSpecies = KdExpressions["exprSpecies"]
            filteredExpressions = {}
            for key, curExpression in expressions.items():
                newExpression = self.replaceVariables(KdExpressions["variables"], curExpression)
                filteredExpressions[key] = self.filterKdExpression(exprSpecies, newExpression)
            resultDict = {} 
            for key, curExpression in filteredExpressions.items():
                value = eval(curExpression)
                resultDict[key] = value
            allKdValues.append(resultDict)
        return allKdValues
    
    def replaceVariables(self, replacementVars, inputString):
        newString = inputString
        for curVar, curValue in replacementVars.items():
            newString = newString.replace(curVar, str(curValue))
        return newString
    
    def filterKdExpression(self, exprSpecies, KdExpression):
        '''
        Takes care of replacing the name of the species in the selected output with their names including units.
        '''
        for curSpecies, details in exprSpecies.items():
            outputType = details["outputQualifier"]
            speciesStr = "" 
            if(outputType == "totals"):
                speciesStr = "_u['" + curSpecies + "(mol/kgw)'][_cell]"
            if(outputType == "molalities"):
                speciesStr += "_u['m_" + curSpecies + "(mol/kgw)'][_cell]"
            KdExpression = KdExpression.replace("'" + curSpecies + "'", speciesStr)
        return KdExpression

    def saveKds(self):
        '''
        Save the Kds for the current time step, so that they can be written to an output file later.
        '''
        curTimeStep = self.timeStep.getCurrentTimeStep()
        self.addKds(curTimeStep, self.numBatchCells, self.KdsValuesTimeStep)

    def addKds(self, curTimeStep, numOfCells, KdsValues):
        for curCell in range(numOfCells):
            for curKd in KdsValues[curCell]:
                self.allKds["Kds"][curKd][curTimeStep][curCell] = KdsValues[curCell][curKd]

    def initializeOutput(self):
        self.allKds["time"] = self.timeStep.getAllTimeSteps()
        numberOfTimeSteps = len(self.allKds["time"])
        self.allKds["tau"] = self.getAllTau()
        numberOfTau = len(self.allKds["tau"])
        Kds = self.radionuclidesInfo.getKds()
        for curKd in Kds:
            self.allKds["Kds"][curKd] = np.zeros((numberOfTimeSteps, numberOfTau))
        self.output.initialize(Kds)

    def generateOutput(self):
        '''
        Write to output file. For now both HDF5 and text files are written.
        '''
        self.output.writeOutputToHDF5(self.streamLineID, self.allKds)

    def writeBins(self, marfaOutput):
        rockType = marfaOutput["rockType"]
        streamLineID = marfaOutput["streamLine"]
        KdInfo = marfaOutput["Kd"]
        KdStatistics, KdStates, uniqueStates, uniqueStatesInv = self.output.determineBinsInHDF5(streamLineID, self.numBatchCells, KdInfo)
        self.output.writeMarfaBins(KdInfo, KdStatistics, uniqueStates, rockType, self.KdFormulation)
        return KdStates, uniqueStatesInv

    def writeKdHistory(self, partTrajectories, KdStates, uniqueStatesInv):
        self.output.writeKdHistoryMarfa(partTrajectories, KdStates, uniqueStatesInv, self.deltaTau, self.deltaTime)