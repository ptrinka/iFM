################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

import os

from LoggerIFM import LoggerIFM
logger = LoggerIFM.getLogger()

class InOutTools:
    def __init__(self, inputPath, outputPath):
        self.inputPath = os.path.normpath(inputPath)
        self.outputPath =  os.path.normpath(outputPath)

    def getPathAndFile(self, inputPath, fileName):
        return os.path.join(inputPath, fileName)
    
    def getOutputPath(self):
        return self.outputPath
    
    def generateFullInputPath(self, fileName):
        return os.path.join(self.inputPath, fileName)
    
    def generateFullOutputPath(self, fileName):
        if(not os.path.exists(self.outputPath)):
            os.mkdir(self.outputPath)
        return os.path.join(self.outputPath, fileName)
    
    def getStringFromFile(self, fileName):
        stringFileName = self.generateFullInputPath(fileName)
        _stringToReturn = ""
        with open(stringFileName, "r") as stringFile:
            _stringToReturn = stringFile.read()
        return _stringToReturn
    
    
    
    