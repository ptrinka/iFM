################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

from LoggerIFM import LoggerIFM
logger = LoggerIFM.getLogger()

from RadionuclidesInfo import RadionuclidesInfo

class ChemicalInformation:
    def __init__(self, chemInfo, aInOutTools):
        self.phreeqcDatabase = chemInfo["phreeqcDatabase"]
        self.phreeqcDatabaseAdditions = chemInfo["phreeqcDatabaseAdditions"]
        self.transportOptions = chemInfo["transportOptions"]
        self.phreeqcContent = chemInfo["phreeqcContent"]
        self.chemDefinitions =  chemInfo["chemDefinitions"]
        self.selectedOutput =  chemInfo["selectedOutput"]
        self.spatialDomains = chemInfo["spatialDomains"]
        self.radionuclidesInfo = RadionuclidesInfo(chemInfo["radioNuclInfo"],self)        
         
        # Set pointers        
        self.inOutTools = aInOutTools
    
    def initialize(self):
        self.phreeqcContentStrings = self.FromDictFileToDictString(self.phreeqcContent)
    
    def FromDictFileToDictString(self, dictFile):
        dictString = {}        
        for curKey in dictFile:
            fileName = dictFile[curKey]
            fileAsString = self.inOutTools.getStringFromFile(fileName)
            dictString[curKey] = fileAsString
        return dictString

    def getTransportSettings(self):
        return self.phreeqcContentStrings["transportSettings"]
    
    def getExtraPhreeqcDatabaseLines(self):
        return self.phreeqcContentStrings[self.phreeqcDatabaseAdditions]
    
    def getSelOutput(self):
        return self.selectedOutput
    
    def GetRadionuclidesReactFiles(self, reactName):        
        reactionsString = self.reactFilesRadionuclidesChemistryString[reactName]       
        return reactionsString

    def getNuclideSolution(self, name):
        solutionName = self.radionuclidesInfo.getNuclideSolution(name)
        nuclideSolution = self.phreeqcContentStrings[solutionName]
        return nuclideSolution
    
    def getNuclideReactions(self, name):
        reactionsName = self.radionuclidesInfo.getNuclideReactions(name)
        nuclideReactions = self.phreeqcContentStrings[reactionsName]
        return nuclideReactions
    
    def getSolution(self, name, solutionKey):
        solutionName = self.chemDefinitions[name][solutionKey]
        solution = self.phreeqcContentStrings[solutionName]
        return solution
    
    def getBoundarySolution(self, name):
        solution = self.getSolution(name, "boundarySolution")
        return solution
    
    def getInitialSolution(self, name):
        solution = self.getSolution(name, "initialSolution")
        return solution
    
    def getReactionsSolution(self, name):
        solution = self.getSolution(name, "reactionsSolutions")
        return solution

    def getSpatialDomain(self, spatialDomain):
        cellRange = self.spatialDomains[spatialDomain]
        listOfCells = [x for x in range(cellRange[0], cellRange[1]+1)]
        return(listOfCells)
    
    def getSpatialBoundaryDomain(self):
        return([0])
    
    def getFractureDomain(self, numberOfCells):
        fractureDom = [self.getSpatialBoundaryDomain()[0],numberOfCells]
        return  fractureDom
    
    def getActualFractureDomain(self, numberOfCells):
        fullFractureDomain = self.getFractureDomain(numberOfCells) 
        newDomain = [fullFractureDomain[0]+1,fullFractureDomain[1]]
        return  newDomain
    
    def getMatrixDomain(self, numberOfCells):
        startIndex = numberOfCells + 1
        matrixDom = [startIndex, startIndex + numberOfCells]
        return  matrixDom
                        
    def getActualMatrixDomain(self, numberOfCells):
        fullMatrixDomain = self.getMatrixDomain(numberOfCells) 
        newDomain = [fullMatrixDomain[0]+1,fullMatrixDomain[1]]
        return  newDomain
    
    def getBatchCellsDomain(self, numberOfCells, useMatrix):
        if useMatrix:
            minBatchCell = 2*(numberOfCells + 1) 
            maxBatchCell = minBatchCell + numberOfCells - 1
        else:
            minBatchCell = numberOfCells + 1 
            maxBatchCell = minBatchCell + numberOfCells - 1
        return [minBatchCell, maxBatchCell]
