################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

from LoggerIFM import LoggerIFM
logger = LoggerIFM.getLogger()

class TimeStep:
    def __init__(self, timeStepInfo):

        self.iniTime = timeStepInfo["iniTime"]
        self.endTime = timeStepInfo["endTime"]
        self.unit = timeStepInfo["unit"]
        self.numOfSteps = 0
        self.currentTime = 0
        self.currentTimeStep = 0
        self.hasStarted = False
        self.prevTime = 0
    
    def initialize(self, deltaTau):
        self.currentTime = self.iniTime
        self.deltaTime = deltaTau
        if(self.unit == "y"):
            self.numOfSteps =  int(((self.endTime - self.iniTime)* 365*24*3600)/deltaTau)
        else: 
            self.numOfSteps =  int(((self.endTime - self.iniTime))/deltaTau)
        
        logger.info("Number of time steps to simulate: " + str(self.numOfSteps))
        
        self.currentTimeStep = 0
        self.hasStarted = False
    
    def getAllTimeSteps(self):
        allTimes = []
        curTime = 0.0
        allTimes.append(curTime)
        for curTimeStep in range(self.numOfSteps):
            curTime += self.deltaTime
            allTimes.append(curTime)
        return(allTimes)
    
    def isFinished(self):
        isFinished = (self.currentTimeStep - 1  == self.numOfSteps)
        return isFinished
    
    def getDeltaTime(self):
        return self.deltaTime
    
    def getCurrentTime(self):
        return self.currentTime
    
    def getCurrentTimeStep(self):
        return self.currentTimeStep

    def getPrevTime(self):
        return self.prevTime
    
    def forwardTimeStep(self):
        self.currentTimeStep += 1
        self.prevTime = self.currentTime 
        self.currentTime += self.deltaTime
        self.hasStarted = True