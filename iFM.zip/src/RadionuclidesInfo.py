################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

from LoggerIFM import LoggerIFM
logger = LoggerIFM.getLogger()

class RadionuclidesInfo:
    def __init__(self, radioNuclInfo, aChemicalInformation):
        self.chemDefinitions = radioNuclInfo["chemDefinitions"]
        self.KdExpressions = radioNuclInfo["KdExpressions"]
        self.chemicalInformation = aChemicalInformation
    
    def getNuclideSolution(self, name):
        nameID = self.chemDefinitions[name]["nuclideSolution"]
        return(nameID)
   
    def getNuclideReactions(self, name):
        nameID = self.chemDefinitions[name]["nuclideReactions"]
        return(nameID)
  
    def getKdSetID(self, name):
        KdId = self.chemDefinitions[name]["Kd"]
        return KdId
    
    def getKdExprSpecies(self, KdSetID):
        KdExprSpecies = self.KdExpressions[KdSetID]["exprSpecies"]
        return KdExprSpecies

    def getKdsExpressions(self, KdSetID):
        expresion = self.KdExpressions[KdSetID]["expressions"] 
        return expresion
    
    def getKdExpressionsDetails(self, KdSetID):
        KdExpressionDetails = self.KdExpressions[KdSetID]
        return KdExpressionDetails

    def getKds(self):
        KdList = []
        for curExprSet in self.KdExpressions.values():
            KdList += curExprSet["expressions"].keys()
        return KdList