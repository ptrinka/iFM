################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################
from time import time


class RunTimer:
    def __init__(self):
        self.startTime = time()
        self.endTime = -1
        self.intermediateTime = self.startTime
        
    def restart(self):
        self.startTime = time()
        
    def stop(self):
        self.endTime = time()
        self.runTime = self.endTime - self.startTime
    
    def getIntermediateRunTime(self):
        curTime = time()
        execTimeSec = curTime - self.startTime
        return execTimeSec
    
    def getRunTime_s_min_h_d_y(self):
        execTimeSec = self.runTime
        execTimeMin = execTimeSec/60.0
        execTimeHours = execTimeMin/60.0
        execTimeDays = execTimeHours/24.0
        execTimeYears = execTimeHours/365.0
        return(execTimeSec, execTimeMin, execTimeHours, execTimeDays, execTimeYears)
    
    def getRunTimeStr(self, unit="h"):
        execTimeSec = self.runTime
        execTimeMin = execTimeSec/60.0
        execTimeHours = execTimeMin/60.0
        execTimeDays = execTimeHours/24.0
        execTimeYears = execTimeDays/365.0
        runTimeStr = "Total time of execution {0:.3g} seconds\n".format(execTimeSec)
        runTimeStr += "Total time of execution {0:.3g} minutes\n".format(execTimeMin)
        if(unit=="h"):
            runTimeStr += "Total time of execution {0:.3g} hours\n".format(execTimeHours)         
        if(unit=="d"):
            runTimeStr += "Total time of execution {0:.3g} hours\n".format(execTimeHours)
            runTimeStr += "Total time of execution {0:.3g} days\n".format(execTimeDays)
        if(unit=="y"):
            runTimeStr += "Total time of execution {0:.3g} days\n".format(execTimeDays)
            runTimeStr += "Total time of execution {0:.3g} hours\n".format(execTimeHours)
            runTimeStr += "Total time of execution {0:.3g} years\n".format(execTimeYears)
        return runTimeStr
    
    
        
        
