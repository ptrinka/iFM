################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

import sys, importlib, os
import argparse

from iFMProblemSetup import iFMProblemSetup
from LoggerIFM import LoggerIFM
from RunTimer import RunTimer

version = "2.0"
lastRevisionDate = "26/08/2015"

def iFM(inputFilePath):
    """The iFM function takes care of the program initialization (setting paths, logger, welcome message, timing, etc.). \n
    The class that is in charge of the actual functionality is :class:`iFMProblemSetup`."""
    
    inputPath = os.path.normpath(os.path.dirname(inputFilePath))
    inputFileName = os.path.basename(inputFilePath)
    sys.path.insert(0, inputPath)
    inputFileWithoutExt =  os.path.splitext(inputFileName)[0] 
    inputConfig = importlib.import_module(inputFileWithoutExt)
    
    LoggerIFM.initialize(inputConfig.simulationConfig["logFile"])
    logger = LoggerIFM.getLogger()

    logger.info(welcomeMessage(version, lastRevisionDate))
    logger.info('Starting')

    timeLogger = RunTimer()

    iFMProblem = iFMProblemSetup(inputConfig.simulationConfig, timeLogger)
    iFMProblem.initialize()
    iFMProblem.run()
    iFMProblem.postProcess()
    logger.info('Finished running iFM')
    
    timeLogger.stop()
    logger.info(timeLogger.getRunTimeStr())

    return(0)

def welcomeMessage(versionID, revDateID):    
    msg = """
    ----------------------------------------
     iFM: interface FastReact to Marfa
     SKB - Amphos21
     version:  """ + versionID + """      
     last revision: """ + revDateID + """
    ----------------------------------------
    """
    return msg

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Run with: python iFM.py fileName')
    parser.add_argument('filename', metavar='fileName', type=str, help="the provided file should contain the full path")
    args = parser.parse_args()
    inputFilePath = vars(args)['filename']
    
    sys.exit(iFM(inputFilePath)) 
