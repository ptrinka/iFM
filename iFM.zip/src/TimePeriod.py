################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

class TimePeriod:
    def __init__(self, timePeriodInfo, aChemicalInformation, aTimestep):
        self.chemicalPeriodDefinitions = timePeriodInfo["chemicalPeriodDefinitions"]
        self.periodFunctions = timePeriodInfo["periodFunctions"]
        self.chemicalInformation = aChemicalInformation
        self.radionuclidesInfo =self.chemicalInformation.radionuclidesInfo
        self.timeStep = aTimestep

    def getCurrentPeriodFunctionName(self, timePeriodType):
        timePeriodFunction = self.periodFunctions[timePeriodType]
        isFound = False
        periodName = "notFound"
        for period in timePeriodFunction:
            initialTime = float(period[0])
            endTime = float(period[1])
            periodTimeName = period[2]
            currentTime = self.timeStep.getCurrentTime() 
            if (currentTime >=initialTime):
                if (currentTime <= endTime):
                    periodName = periodTimeName
                    isFound = True
            if (isFound):
                break
        return periodName
        
    def getGeneralChemistrySolutionConcentrations(self, timePeriodType):

        periodFuncName = self.getCurrentPeriodFunctionName(timePeriodType)
        chemSolutionName = self.chemicalPeriodDefinitions[periodFuncName]
        chemSolutionString = self.chemicalInformation.GetGeneralChemistry(chemSolutionName)
        return chemSolutionString
   
    def getPeriodID(self, timePeriodType):
        periodFuncName = self.getCurrentPeriodFunctionName(timePeriodType)
        periodID = self.chemicalPeriodDefinitions[periodFuncName]
        return periodID
        
    def getKdsExpressions(self, timePeriodsRadionuclids):
        timePeriodFunction = self.periodFunctions[timePeriodsRadionuclids]
        isFound = False
        periodName = "notFound"
        for period in timePeriodFunction:
            initialTime = float(period[0])
            endTime = float(period[1])
            periodTimeName = period[2]
            currentTime = self.timeStep.getCurrentTime() 
            if (currentTime >=initialTime):
                if (currentTime <= endTime):
                    periodName = periodTimeName
                    isFound = True
            if (isFound):
                break
        kdId = self.chemicalPeriodDefinitions[periodName]
        kdsExpresionsToReturn = self.radionuclidesInfo.getKdsExpressions(kdId)
        return kdsExpresionsToReturn
