################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

from LoggerIFM import LoggerIFM
logger = LoggerIFM.getLogger()

class ParticleTrajectories:
    def __init__(self, trajectoriesInputFile, timeUnit):
        self.tau = 0
        self.inputFileName = trajectoriesInputFile
        self.unit = timeUnit
        self.inputFile = -1
        self.currentTrajectoryIndex = 0
        self.numOfTrajectories = -1

    def readFileHeader(self, inpFile):
        _curLine = inpFile.readline()
        curLine = inpFile.readline()
        self.numOfTrajectories = int(curLine.split()[0])
    
    def readTrajectoryHeader(self, inpFile):
        trajID, xLoc, yLoc, zLoc = inpFile.readline().split()
        return trajID, xLoc, yLoc, zLoc
        
    def getMaxTau(self):
        logger.info("Opening particle trajectories file:" + self.inputFileName)
        tauMaxList = []
        with open(self.inputFileName,  "r") as inpFile:
            # Read headerLine
            self.readFileHeader(inpFile)
            for _i in range(self.numOfTrajectories):
                # Read headerLine
                self.readTrajectoryHeader(inpFile)
                readTrajectory = False
                tau = 0.0
                while(not readTrajectory):
                    curLine = inpFile.readline().split()
                    if(curLine[0] != "END"):
                        tau += float(curLine[4])
                    else:
                        readTrajectory = True
                tauMaxList.append(tau)
        logger.info("Read in particle trajectories.")
        if(self.unit == "y"):
            tauMaxList = [i * 365*24*3600 for i in tauMaxList]

        maxTau = max(tauMaxList)
        return maxTau
    
    def getTrajectory(self):
        tauList = []
        readTrajectory = False
        tau = 0.0
        while(not readTrajectory):
            curLine = self.inputFile.readline().split()
            if(curLine[0] != "END"):
                tau += float(curLine[4])
                tauList.append(tau)
            else:
                readTrajectory = True
        return tauList
    
    def getFirstTrajectory(self):
        if(self.currentTrajectoryIndex == 0):
            self.inputFile = open(self.inputFileName,  "r")
            self.readFileHeader(self.inputFile)
            # Read headerLine
            curTrajectoryID, _x, _y, _z = self.readTrajectoryHeader(self.inputFile)
            tauList = self.getTrajectory()
            self.currentTrajectoryIndex += 1
        return self.currentTrajectoryIndex, curTrajectoryID, tauList 
    
    def getNextTrajectory(self):
        curTrajectoryID = -1
        tauList = []
        if(self.currentTrajectoryIndex < self.numOfTrajectories):
            curTrajectoryID, _x, _y, _z = self.readTrajectoryHeader(self.inputFile)
            tauList = self.getTrajectory()
            self.currentTrajectoryIndex += 1
        else:
            self.inputFile.close()
            self.currentTrajectoryIndex = 0
        return self.currentTrajectoryIndex, curTrajectoryID, tauList
    
    def getNumOfTrajectories(self):
        return self.numOfTrajectories