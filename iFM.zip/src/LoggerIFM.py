################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

import logging
import os

class LoggerIFM:
    @staticmethod
    def initialize(logFilePath):
        logLevel = logging.INFO
        # create logger with 'spam_application'
        logger = logging.getLogger('iFMlogger')
        logger.setLevel(logging.DEBUG)
        # create file handler which logs even debug messages
        logPath = os.path.dirname(logFilePath)
        if(not os.path.exists(logPath)):
            os.mkdir(logPath)
        fh = logging.FileHandler(logFilePath)
        fh.setLevel(logLevel)
        #fh.setLevel(logging.INFO)
        # create console handler with a higher log level
        ch = logging.StreamHandler()
        #ch.setLevel(logLevel)
        ch.setLevel(logging.CRITICAL)
        # create formatter and add it to the handlers
        formatter = logging.Formatter('%(asctime)s - %(levelname)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        fh.setFormatter(formatter)
        #ch.setFormatter(formatter)
        # add the handlers to the logger
        logger.addHandler(fh)
        logger.addHandler(ch)

    @staticmethod
    def getLogger():
        return(logging.getLogger("iFMlogger"))
    