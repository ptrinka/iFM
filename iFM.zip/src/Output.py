################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

import math
import numpy as np
import h5py

from LoggerIFM import LoggerIFM
logger = LoggerIFM.getLogger()

class Output:
    '''
    This class takes care of writing to output files.
    '''
    def __init__(self, inOutTools, outputFileName, marfaOutput):

        # pointer selection
        self.inOutTools = inOutTools
        self.hdf5File = None
        self.KdNames = []
        self.outputFileName = outputFileName
        self.outputFilePathHDF5 = ""       
        self.marfaKdBinsFile = ""
        self.marfaKdHistoryFile = ""
        self.marfaStatePrefix = "S"
        self.marfaDelimiter = 2*" "
        self.marfaOutputFileNames = marfaOutput["outputFiles"]
        self.timeUnit = marfaOutput["timeUnit"]
        

    def initialize(self, Kds):
        self.outputFilePathHDF5 = self.inOutTools.generateFullOutputPath(self.outputFileName["HDF5"])
        
        self.marfaKdBinsFile = self.inOutTools.generateFullOutputPath(self.marfaOutputFileNames["kdbins"])
        self.marfaKdHistoryFile = self.inOutTools.generateFullOutputPath(self.marfaOutputFileNames["kdhistory"])

        # time, tau, Kd
        for curKd in Kds:
            self.KdNames.append(curKd)
    
    def writeOutputToHDF5(self, strLineID, allKds):
        ''' Writes output to HDF5'''
        self.writeToHDF5(self.outputFilePathHDF5, strLineID, allKds)
        
    def writeToHDF5(self, outputFilePathHDF5, lineID, allKds):
        if(outputFilePathHDF5 != ""):
            with h5py.File(outputFilePathHDF5,mode='w') as self.hdf5File:
                datasetStrLineName = "Streamline/" + str(lineID) + "/"
                datasetName = datasetStrLineName + "Time"
                timeArray = np.array(allKds["time"])
                _h5dset = self.hdf5File.create_dataset(datasetName, data=timeArray)
                datasetName = datasetStrLineName + "Tau"
                tauArray = np.array(allKds["tau"])
                _h5dset = self.hdf5File.create_dataset(datasetName, data=tauArray)
                for curKd in self.KdNames:
                    datasetName = datasetStrLineName + "Kd/" + curKd 
                    KdArray = allKds["Kds"][curKd]
                    _h5dset = self.hdf5File.create_dataset(datasetName, data=KdArray)

            logger.info('HDF5 output file written:' + outputFilePathHDF5)
       
    def constructMarfaID(self, stateList):
        newID = "".join([self.marfaStatePrefix + str(x).zfill(2) for x in stateList])
        return newID
    
    def getStateListFromMarfaID(self, marfaID):
        newString = marfaID.lstrip(self.marfaStatePrefix)
        stateList = [int(x) for x in newString.split(self.marfaStatePrefix)]
        return stateList
       
    def determineBinsInHDF5(self, lineID, numberOfCells, KdInfo):
        KdStatistics = {}

        with h5py.File(self.outputFilePathHDF5,mode='r') as hdf5File:
            allTimes = hdf5File["Streamline/" + str(lineID) + "/Time"]
            numOfTimeSteps = allTimes.shape[0]
            allKds = hdf5File["Streamline/" + str(lineID) + "/Kd"]
            for curKd in KdInfo:
                KdStatistics[curKd] = {}
                KdStatistics[curKd]["occurrences"], bins = np.histogram(allKds[curKd], KdInfo[curKd]["numberOfBins"])
                KdStatistics[curKd]["bins"] = bins
                KdBinString = "\n" + "Number of values per bin for KD: " + curKd + "\n"
                for i in range(len(KdStatistics[curKd]["bins"])):
                    if(i != 0):
                        binString = "[" + str(KdStatistics[curKd]["bins"][i-1]) + " - " + str(KdStatistics[curKd]["bins"][i]) + "]"
                        binStatsString = " : " + str(KdStatistics[curKd]["occurrences"][i-1])
                        KdBinString += binString + binStatsString
                        if(i != len(KdStatistics[curKd]["bins"]) -1):
                            KdBinString += "\n"
                logger.info(KdBinString)
                KdStatistics[curKd]["binAverages"] = []
                for curBinIndex in range(len(bins) - 1):
                    avgBinValue = (bins[curBinIndex] + bins[curBinIndex+1]) / 2.0
                    KdStatistics[curKd]["binAverages"].append(avgBinValue)

                newBins = np.array(bins)
                newBins[-1] += 1.0 
                KdStatistics[curKd]["correctedBins"] = newBins
                KdStatistics[curKd]["assignedBins"] = {}
                for curTimeStep in range(allKds[curKd].shape[0]):
                    newAssignedBins = np.digitize(allKds[curKd][curTimeStep], newBins)
                    KdStatistics[curKd]["assignedBins"][curTimeStep] = newAssignedBins
        uniqueStates, uniqueStatesInv = self.getUniqueStates(numberOfCells, numOfTimeSteps, KdStatistics, KdInfo)

        KdStates = { "KdStateLists" : [],
                     "KdTimeStepsLists" : []}
        for curTau in range(numberOfCells):
            prevState = -1
            KdStateList = []
            KdTimeStepsList = []
            for curTimeStep in range(numOfTimeSteps):
                stateList = [KdStatistics[curKd]["assignedBins"][curTimeStep][curTau] for curKd in KdInfo]
                curKdBins = self.constructMarfaID(stateList)
                newState = uniqueStates[curKdBins]
                if(newState != prevState):
                    KdStateList.append(newState)
                    KdTimeStepsList.append(curTimeStep)
                    prevState = newState
            KdStates["KdStateLists"].append(KdStateList)
            KdStates["KdTimeStepsLists"].append(KdTimeStepsList)
        return KdStatistics, KdStates, uniqueStates, uniqueStatesInv

    def writeMarfaBins(self, KdInfo, KdStatistics, uniqueStates, rockTypeID, KdFormulation):
        if(self.marfaKdBinsFile != ""):
            allElements = KdStatistics.keys()
            headerLine = "1\n"
            headerLine += self.marfaDelimiter + rockTypeID + "\n"
            with open(self.marfaKdBinsFile,  "w") as outputFile:
                headerLine += self.marfaDelimiter + str(len(uniqueStates))
                headerLine += " ! " + " ".join([x for x in KdInfo.keys()])  + "\n"
                outputFile.write(headerLine)
                for stateValues, stateID in uniqueStates.items():
                    stateList = self.getStateListFromMarfaID(stateValues)
                    binLabel =  self.constructMarfaID(stateList)
                    outputFile.write(2*self.marfaDelimiter + binLabel + "\n")
                    elemList = []
                    KdList = list(KdInfo.keys())
                    for curKdIndex in range(len(KdList)):
                        curElem = KdList[curKdIndex]
                        curBin = int(stateList[curKdIndex]) - 1
                        elemList.append("{:g}".format(KdStatistics[curElem]["binAverages"][curBin]))
                    outputFile.write(2*self.marfaDelimiter + " ".join(elemList) + "\n")
                    if(KdFormulation == "LD"):
                        outputFile.write(2*self.marfaDelimiter + " ".join(elemList) + "\n")
            logger.info('Marfa input file written:'  + self.marfaKdBinsFile)
    
    def writeMarfaKdHistoryHeader(self, numOfTrajs, outputFile):
        outputFile.write(str(numOfTrajs) + "\n")
        
    def writeMarfaKdHistTrajHeader(self, curTrajID, outputFile):
        outputFile.write(self.marfaDelimiter + str(curTrajID) + "\n")
        
    def writeMarfaKdHistTrajDetails(self, KdStates, uniqueStatesInv, deltaTau, deltaTime, tauList, outputFile):
        for curTau in tauList:
            tauIndex = math.ceil(curTau/deltaTau) - 1
            numOfStates = len(KdStates["KdStateLists"][tauIndex])
            outputFile.write(2*self.marfaDelimiter + str(numOfStates) + "\n")
            curStates = KdStates["KdStateLists"][tauIndex]
            stateList = [uniqueStatesInv[x] for x in curStates]
            outputFile.write(2*self.marfaDelimiter + " ".join(stateList) + "\n")
            timeList = []
            secsToYearsFactor = 31536000.0
            for curTimeStep in KdStates["KdTimeStepsLists"][tauIndex]:
                if(curTimeStep != 0):
                    if(self.timeUnit == "s"):
                        timeList.append("{:g}".format(curTimeStep*deltaTime))
                    elif(self.timeUnit == "y"):
                        timeList.append("{:g}".format(curTimeStep*deltaTime/secsToYearsFactor))
            outputFile.write(2*self.marfaDelimiter + " ".join(timeList) + "\n")
        outputFile.write(self.marfaDelimiter + "END\n")

        
    def writeKdHistoryMarfa(self, partTrajectories, KdStates, uniqueStatesInv, deltaTau, deltaTime):
        numOfTrajs = partTrajectories.getNumOfTrajectories()
        with open(self.marfaKdHistoryFile,  "w") as outputFile:
            self.writeMarfaKdHistoryHeader(numOfTrajs, outputFile)

            curTrajIndex, curTrajID, tauList = partTrajectories.getFirstTrajectory()
            self.writeMarfaKdHistTrajHeader(curTrajID, outputFile)
            self.writeMarfaKdHistTrajDetails(KdStates, uniqueStatesInv, deltaTau, deltaTime, tauList, outputFile)
            
            while True:
                curTrajIndex, curTrajID, tauList = partTrajectories.getNextTrajectory()
                if(curTrajIndex != 0):
                    self.writeMarfaKdHistTrajHeader(curTrajID, outputFile)
                    self.writeMarfaKdHistTrajDetails(KdStates, uniqueStatesInv, deltaTau, deltaTime, tauList, outputFile)
                else:
                    break
       
    def getUniqueStates(self, 
                        numberOfCells, 
                        numOfTimeSteps, 
                        KdStatistics, 
                        KdInfo):
        uniqueStates = {}
        uniqueStatesInv = {}
        stateID = 1
        for curTau in range(numberOfCells):
            for curTimeStep in range(numOfTimeSteps):
                stateList = [KdStatistics[curKd]["assignedBins"][curTimeStep][curTau] for curKd in KdInfo]
                curState = self.constructMarfaID(stateList)
                if curState not in uniqueStates:
                    uniqueStates[curState] = stateID
                    uniqueStatesInv[stateID] = curState 
                    stateID += 1
        return uniqueStates, uniqueStatesInv