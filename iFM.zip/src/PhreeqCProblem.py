################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

from phreeqpy_dll import IPhreeqc

from LoggerIFM import LoggerIFM
logger = LoggerIFM.getLogger()

class PhreeqCProblem:
    '''
    Class that deals with all the interaction between iFM and Phreeqc (IPhreeqc library).
    '''
    def __init__(self, phreeqcDll, phreeqcDatabase, aInOutTools):
        self.phreeqcDll = phreeqcDll        
        self.phreeqcDatabase = phreeqcDatabase
        self.inOutTools = aInOutTools
        
        self.stringLoaded = ""
        
    def initialize(self):
        '''
        Initialization of the Phreeqc DLL.
        
        Loads the DLL, thermodynamic database and turns on selected output.
        '''
        self.iPhreeqPy = IPhreeqc(self.phreeqcDll)
        dbPath = self.inOutTools.generateFullInputPath(self.phreeqcDatabase)
        self.iPhreeqPy.load_database(dbPath)
        self.iPhreeqPy.set_selected_output_file_off()
    
    def getComponents(self):
        componentsList = self.iPhreeqPy.get_component_list()
        return componentsList    

    def replaceOrAddStringIfNotOFound(self, multiLineString, stringToFind, newRestOfLine, addInBetween=" "):
        splitLines = multiLineString.split("\n")
        # remove ending spaces
        allStrLines = [x.rstrip() for x in splitLines]
        # remove empty lines
        strLines = [x for x in  allStrLines if x != ""]
        foundString = False
        for lineIndex in range(len(strLines)):
            curLine = strLines[lineIndex]
            if stringToFind in curLine:
                newStrLoc = curLine.find(stringToFind) + len(stringToFind) 
                strLines[lineIndex] = strLines[lineIndex][0:newStrLoc] + addInBetween + newRestOfLine + " #" + strLines[lineIndex][newStrLoc:].strip()
                foundString = True
        if(not foundString):
            resultString = "\n".join(strLines) + "\n    "  + stringToFind + addInBetween + newRestOfLine + "\n"
        else:
            resultString = "\n".join(strLines)
        return resultString
    
    def replaceString(self, multiLineString, stringToFind, newRestOfLine, addInBetween=" "):
        splitLines = multiLineString.split("\n")
        # remove ending spaces
        allStrLines = [x.rstrip() for x in splitLines]
        # remove empty lines
        strLines = [x for x in  allStrLines if x != ""]
        for lineIndex in range(len(strLines)):
            curLine = strLines[lineIndex]
            if stringToFind in curLine:
                newStrLoc = curLine.find(stringToFind) + len(stringToFind) 
                strLines[lineIndex] = strLines[lineIndex][0:newStrLoc] + addInBetween + newRestOfLine + " #" + strLines[lineIndex][newStrLoc:].strip()
        resultString = "\n".join(strLines)
        return resultString

    def loadTransportSettings(self, 
                              transportSettingsString, 
                              stagOptions, 
                              numberOfCells, 
                              initialTime, 
                              numOfSecondsToRun):
        '''
        Generate string with number of cells, time_step and initial_time. 
        '''
        transportSettingsStringModified1 = self.replaceOrAddStringIfNotOFound(transportSettingsString, "-cells", str(numberOfCells))
        transportSettingsStringModified2 = self.replaceOrAddStringIfNotOFound(transportSettingsStringModified1, "-time_step", str(numOfSecondsToRun))
        transportSettingsStringModified3 = self.replaceOrAddStringIfNotOFound(transportSettingsStringModified2, "-initial_time", str(initialTime))
        transportSettingsStringModified4 = self.replaceOrAddStringIfNotOFound(transportSettingsStringModified3, "-shift", str(1))
        transportSettingsStringModified5 = self.replaceOrAddStringIfNotOFound(transportSettingsStringModified4, "-length", str(1))
        if(len(stagOptions) > 0):
            transportSettingsStringModified5 += "\n-stag 1 " + str(stagOptions["exchangeFactor"]) + \
                                                " " + str(stagOptions["mobilePorosity"]) + \
                                                " " + str(stagOptions["matrixPorosity"]) + "\n" 
        self.stringLoaded  += transportSettingsStringModified5             
    
    def loadCellsInfoSolution(self, cellsList, fileString):
        for cell in cellsList:
            newString = self.replaceOrAddStringIfNotOFound(fileString, "SOLUTION", str(cell))
            self.stringLoaded  += newString + "\n"
            
    def loadCellsInfoEquilibrium(self, cellsList, fileString):
        for cell in cellsList:
            newString = self.replaceString(fileString, "EQUILIBRIUM_PHASES", str(cell))
            newString = self.replaceString(newString, "EXCHANGE", str(cell))
            self.stringLoaded  += newString.rstrip() + "\n" 
        

    def runAccumulated(self):
        '''
        Run the PhreeqC commands, specified earlier.
        '''
        logger.debug(self.stringLoaded)
        self.iPhreeqPy.run_string(self.stringLoaded)
        self.stringLoaded = ""
    
    def loadString(self, stringWithCommands):
        self.stringLoaded += stringWithCommands + "\n"
    
    def addEndTag(self):
        self.stringLoaded += "\n END \n"
        
    def getCurrentCommand(self):
        return(self.stringLoaded)

    def loadRunCell(self, cell, initialTime, deltaTime):
        ''' Load cell to run '''
        runCellsStrings = "RUN_CELLS \n" 
        runCellsStrings += "\t -cells " + str(cell) + "\n"
        runCellsStrings += "\t -time_step "   + str(deltaTime) + "\n"
        runCellsStrings += "\t -start_time "   + str(initialTime) + "\n"

        self.stringLoaded  += runCellsStrings
    
    def loadRunCellNoTime(self, cell):
        ''' Load cell to run '''
        runCellsStrings = "RUN_CELLS \n" 
        runCellsStrings += "\t -cells " + str(cell) + "\n"

        self.stringLoaded  += runCellsStrings
    
    
    def loadRunCells(self, minMaxIndices, initialTime, deltaTime):
        ''' Load cell range to run '''
        runCellsStrings = "RUN_CELLS \n" 
        runCellsStrings += "\t -cells " + str(minMaxIndices[0]) + "-" + str(minMaxIndices[1]) + "\n"
        runCellsStrings += "\t -time_step "   + str(deltaTime) + "\n"
        runCellsStrings += "\t -start_time "   + str(initialTime) + "\n"        
                
        self.stringLoaded  += runCellsStrings
    
    def getSelectedOutputValues(self):
        """Return calculation result as dict.
    
        Header entries are the keys and the columns
        are the values as lists of numbers.
        """
        output = self.iPhreeqPy.get_selected_output_array()
        header = output[0]
        conc = {headerValue:[] for headerValue in header}
        detailRows = output[1:]
        for row in detailRows:
            for col, head in enumerate(header):
                conc[head].append(row[col])
        return conc
        
    def duplicateCells(self, cellsToCopy, cellsTarget):
        ''' Duplicate the complete chemistry from one set of cells to a target range of cells '''
        outputStr = ""
        rangeCellsToCopy = range(cellsToCopy[0], cellsToCopy[1] + 1)
        rangeCellsTarget = range(cellsTarget[0], cellsTarget[1] + 1)

        numOfCellsToCopy = cellsToCopy[1]-cellsToCopy[0] + 1
        for i in range(numOfCellsToCopy):
            outputStr += "COPY solution %d %d\n" % (rangeCellsToCopy[i],rangeCellsTarget[i])
            outputStr += "COPY equilibrium_phases %d %d\n" % (rangeCellsToCopy[i],rangeCellsTarget[i])
            outputStr += "COPY exchange %d %d\n" % (rangeCellsToCopy[i],rangeCellsTarget[i])
            outputStr += "COPY surface %d %d\n" % (rangeCellsToCopy[i],rangeCellsTarget[i])
            outputStr += "COPY solid_solution %d %d\n" % (rangeCellsToCopy[i],rangeCellsTarget[i])
            outputStr += "COPY gas_phase %d %d\n" % (rangeCellsToCopy[i],rangeCellsTarget[i])
            outputStr += "COPY kinetics %d %d\n" % (rangeCellsToCopy[i],rangeCellsTarget[i])
            outputStr += "COPY reaction %d %d\n" % (rangeCellsToCopy[i],rangeCellsTarget[i])
            outputStr += "COPY reaction_temperature %d %d\n" % (rangeCellsToCopy[i],rangeCellsTarget[i])
        
        outputStr += "END\n"        
        self.stringLoaded  += outputStr        
    
    def applyModifySolutionAtCopiedCells(self, solution, batchCellDomain):
        outputStr = ""
        if(solution.strip() != ""):
            rangeCells = range(batchCellDomain[0], batchCellDomain[1]+1)
            for i in rangeCells:
                solutionOut = self.replaceOrAddStringIfNotOFound(solution, "SOLUTION", "_MODIFY " + str(i), "")
                outputStr += solutionOut + "\n"
        self.stringLoaded  += outputStr
        
    def applyModifyBoundarySolution(self, solution, numOfCells, currentTime, deltaTime, useMatrix):
        outputStr =""
        if(solution.strip() != ""):
            applyToCell = 0
            outputStr = self.replaceOrAddStringIfNotOFound(solution, "SOLUTION", " " + str(applyToCell) + "\n")
            self.stringLoaded  += outputStr
            if useMatrix:
                applyToCell = numOfCells + 1
                outputStr = self.replaceOrAddStringIfNotOFound(solution, "SOLUTION", " " + str(applyToCell) + "\n")
                self.stringLoaded  += outputStr
                self.addEndTag()
                self.loadRunCell(applyToCell, currentTime, deltaTime)
        
        
    def applyModifyReactionsAtCopiedCells(self, reactions, batchCellDomain):
        outputStr = ""
        if(reactions.strip() != ""):
            rangeCells = range(batchCellDomain[0], batchCellDomain[1]+1)
            for cell in rangeCells:
                reactOut = self.replaceString(reactions, "EXCHANGE", str(cell))
                reactOut = self.replaceString(reactOut, "-equilibrate with solution", str(cell))
                outputStr += reactOut + "\n"
        self.stringLoaded  += outputStr
    
    def generateSelectedOutput(self, outputSpecies, selectedOutput):
        '''
        Generate the selected output string to pass to Phreeqc. 
        
        For now only "totals" and "molalities" are considered. 
        '''
        outputStr = "SELECTED_OUTPUT \n"

        for typeOfOutput, outputValue in selectedOutput.items():
            outputStr += "\t" + typeOfOutput + " " + str(outputValue) + "\n"
        totalsStr =  "-totals" + "\t"
        molalitiesStr =  "-molalities" + "\t"  
        for curSpecies, details in outputSpecies.items():
            outputType = details["outputQualifier"]
            if(outputType == "totals"): 
                totalsStr +=  " " +  curSpecies
            elif(outputType == "molalities"):
                molalitiesStr +=  " " +  curSpecies
        outputStr += totalsStr + "\n"
        outputStr += molalitiesStr + "\n"
        return outputStr
    
    def setUpOutput(self, 
                    KdExprSpecies, 
                    selOutputValues):
        newSelOutput = self.generateSelectedOutput(KdExprSpecies, selOutputValues)
        self.loadString(newSelOutput)
        
    def copyDomainsAndApplyReactions(self, 
                                     currentTime,
                                     deltaTime,
                                     sourceDomain, 
                                     batchCellDomain,
                                     nuclideSolution,
                                     nuclideReactions):
        # copy transport reactions on batch cells
        self.duplicateCells(sourceDomain, batchCellDomain)
        
        # apply radionuclide concentrations to cells
        self.applyModifySolutionAtCopiedCells(nuclideSolution, 
                                              batchCellDomain)
        # apply radionuclide reactions to cells
        self.applyModifyReactionsAtCopiedCells(nuclideReactions, 
                                                              batchCellDomain)
        self.loadRunCells(batchCellDomain,
                                         currentTime, 
                                         deltaTime)
        self.addEndTag()
        self.runAccumulated()
        radionuclideValues = self.getSelectedOutputValues()
        
        logger.debug('Calculated batch reactions')
        return radionuclideValues
    
    
    def runDomain(self, 
                  runDomain, 
                  currentTime, 
                  deltaTime):
        self.loadRunCells(runDomain,
                          currentTime, 
                          deltaTime)
        self.runAccumulated()
        
        
    def runTransport(self, 
                     transportSettingsString,
                     transportStagOptions,
                     boundarySolution, 
                     numberOfCells,
                     currentTime,
                     deltaTime,
                     useMatrix):
        self.applyModifyBoundarySolution(boundarySolution, 
                                     numberOfCells, 
                                     currentTime,
                                     deltaTime,
                                     useMatrix)
        self.runAccumulated()
        stagOptions = {}
        if useMatrix:
            stagOptions = transportStagOptions
        self.loadTransportSettings(transportSettingsString,
                                   stagOptions, 
                                   numberOfCells, 
                                   currentTime,
                                   deltaTime)
        self.runAccumulated()