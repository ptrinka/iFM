################################################################################################
# iFM 
# Copyright (C) 2013 Posiva Oy, SKB, Amphos 21
#iFM is property of POSIVA Oy and SKB
#use iFM at your own risk
################################################################################################

from LoggerIFM import LoggerIFM
logger = LoggerIFM.getLogger()

from Streamline import Streamline
from TimeStep import TimeStep
from ParticleTrajectories import ParticleTrajectories
from ChemicalInformation import ChemicalInformation
from TimePeriod import TimePeriod
from InOutTools import InOutTools
from Output import Output

class iFMProblemSetup:
    '''
    The main class that controls iFM. 
    
    It takes care of the following tasks:
     
    #. Process the configuration file, 
    #. Read the particle trajectories file 
    #. Run the PhreeqC simulation for the reference streamline 
    #. Filters the output Kds. This HDF5 file is processed to prepare an input file for Marfa.
    '''
    
    def __init__(self, simulationConfig, timeLogger):
        '''
        Get configuration flags and create attribute objects (e.g. Streamline) 
        '''
        # read general information
        self.name = simulationConfig["simulationTitle"]
        self.inOutTools =  InOutTools(simulationConfig["inputPath"], simulationConfig["outputPath"])

        # create other instances 
        self.timeStep = TimeStep(simulationConfig["timeStepInfo"])
        
        self.MarfaOutput = simulationConfig["MarfaOutput"]
        
        self.outputFile = simulationConfig["outputFile"]
        self.output = Output(self.inOutTools, self.outputFile, self.MarfaOutput)
                
        self.partTrajectories = ParticleTrajectories(simulationConfig["trajectoriesInputFile"], simulationConfig["trajectoriesTimeUnit"])
        
        self.chemicalInformation = ChemicalInformation(simulationConfig["chemInfo"], 
                                                       self.inOutTools)
        self.timePeriod = TimePeriod(simulationConfig["timePeriodInfo"], 
                                     self.chemicalInformation, 
                                     self.timeStep)
        self.StreamLineToRunID = simulationConfig["streamLineToRun"]
        self.StreamLineToRun = simulationConfig["streamLines"][self.StreamLineToRunID]
        self.streamlineOfReference = Streamline(self.StreamLineToRunID,
                                                self.StreamLineToRun,
                                                self.inOutTools, 
                                                self.chemicalInformation, 
                                                self.timePeriod, 
                                                self.output, 
                                                self.timeStep)
        logger.info("Problem read in.")  
        self.timeLogger = timeLogger          
        
    def initialize(self):
        '''
         * Read the particle trajectory files
         * Calculate the time steps
         * Read in PhreeqC files for different chemistries
         * Initialize PhreeqC for the reference streamline
        '''
        tauMax = self.partTrajectories.getMaxTau()
        self.chemicalInformation.initialize()
        self.streamlineOfReference.initialize(0.0, tauMax)
        deltaTau = self.streamlineOfReference.getDeltaTau()
        self.timeStep.initialize(deltaTau)
        self.streamlineOfReference.initializeOutput()
        logger.info('Problem initialized')
        
    def run(self):
        '''
        Run the initial time step first, calculate the Kds and then enter the time loop.
        When the Kds for all time steps are collected, they are written to the output file(s)
        '''
        self.streamlineOfReference.calculateInitialConditions()
        self.streamlineOfReference.computeKds()
        logger.info('Calculated initial Kds')
        self.streamlineOfReference.saveKds()
        
        self.timeStep.forwardTimeStep()
        while (not self.timeStep.isFinished()):
            logger.info("solving time step " + str(self.timeStep.currentTimeStep) + "/" 
                        + str(self.timeStep.numOfSteps) + ": " + str(self.timeStep.getCurrentTime()) + " (s)")    
            self.streamlineOfReference.computeTransportGeneralChemistryStep(self.timeLogger)                                                  
            self.streamlineOfReference.computeKds()
            self.streamlineOfReference.saveKds()
            self.timeStep.forwardTimeStep()
        self.streamlineOfReference.generateOutput()
        
    def postProcess(self):
        '''
        Filter the Kd values according to a minimum relative change. Write the result to output file(s) 
        '''
        KdStates, uniqueStatesInv = self.streamlineOfReference.writeBins(self.MarfaOutput)
        self.streamlineOfReference.writeKdHistory(self.partTrajectories, KdStates, uniqueStatesInv)
        
         
        