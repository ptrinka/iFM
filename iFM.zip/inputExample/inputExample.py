import os
#===============================================================================
# iFM Configuration
#===============================================================================
inputPath = os.path.dirname(__file__)
outputPath = inputPath + "/results"
simulationConfig = {
  "inputPath" : inputPath,
  "outputPath" : outputPath,
  "outputFile": {"HDF5" : "Kds.h5"},
  "logFile" : outputPath + "/iFM.log",
  "simulationTitle" : "Example 1",
  "trajectoriesInputFile" : inputPath + "/trajectories.dat",
  "trajectoriesTimeUnit" : "s",
  "streamLineToRun" : "STR1",

  #===============================================================================
  # streamline information
  #===============================================================================
  "streamLines" : {"STR1" : {"numberOfCells" : 210,
                             "tauChemicalDomains" : {"domainChem1" : "spatialDomainChem1"},
                             "timePeriodsGeneralChemistry" : "periodChemistry",
                             "timePeriodsRadionuclids" : "periodRadionuc",
                             "KdFormulation" : "ES"} # "LD" or "ES"
                   },
  #===============================================================================
  # Time periods
  #===============================================================================
  "timePeriodInfo" : {"periodFunctions" : {"periodChemistry":[[0, 6.34e11, "periodGenChem1"], 
                                                              [6.34e11, 7.884e11, "periodGenChem2"]], 
                                           "periodRadionuc":[[0, 7.884e11, "periodRad1"]]},
                      "chemicalPeriodDefinitions" : 
                                          {"periodGenChem1":"genChem",
                                           "periodGenChem2": "genChem2",
                                           "periodRad1":"CesiumAndCalciumInfoAndKds"
                                           }
                    },
  #===============================================================================
  # phreeqc chemical information
  #===============================================================================
  "chemInfo" : 
       {"spatialDomains" : {"spatialDomainChem1" : [1, 210]},
        "phreeqcDatabase" : "tdatabase.dat",
        "phreeqcDatabaseAdditions" : "extraDBLines",
        "transportOptions" : {"exchangeFactor" : 1.0e-13,
                              "mobilePorosity" : 4.4e-2,
                              "matrixPorosity" : 1.0e-2},
        "chemDefinitions" : {"genChem" : {"boundarySolution":"boundWater1"},
                             "genChem2" : {"boundarySolution":"boundWater2"},
                             "domainChem1" : {"initialSolution" : "iniWater",
                                              "reactionsSolutions" : "reactInWater1"}},
        "phreeqcContent" : {"extraDBLines" : "databaseAdditions.dat",
                            "iniWater": "solutionInitial.dat",
                            "radionuclidesWater1":"solutionRadioNucl.dat",
                            "boundWater1":"solutionBoundary1.dat",
                            "boundWater2":"solutionBoundary2.dat",
                            "reactRadionuclides1":"chemistryBatch.dat",
                            "reactInWater1" : "chemistryFracture.dat",
                            "reactInMatrix1" : "chemistryFracture.dat",
                            "transportSettings" : "transportSettings.dat"},
        "selectedOutput" :  {
                          "-activities":[],                    
                          "-equilibrium_phases":["Calcite"],
                          "-saturation_indices":["Calcite"],
                          "-gases":[],
                          "-kinetic_reactants":[],
                          "-solid_solutions":[],
                          "-reset" : "true",
                          "-high_precision" : "false",
                          "-simulation" : "false",
                          "-state" : "false",
                          "-solution" : "true",
                          "-time" : "true",
                          "-step" : "true",
                          "-ph" : "true",
                          "-pe" : "true",
                          "-reaction" : "false",
                          "-temperature" : "false",
                          "-alkalinity" : "false",
                          "-ionic_strength" : "false",
                          "-water" : "true",
                          "-charge_balance" : "false",
                          "-percent_error" : "false"},
        #===============================================================================
        # Radionuclide and Kd information
        #===============================================================================
        "radioNuclInfo" : 
            {"chemDefinitions" : {"CesiumAndCalciumInfoAndKds" : 
                                 {"nuclideSolution" : "radionuclidesWater1",
                                  "nuclideReactions" : "reactRadionuclides1",
                                  "Kd" : "KdExpressions1"}},
             "KdExpressions" : 
                    {"KdExpressions1" : 
                      {"exprSpecies" : {"[90Sr]":   {"outputQualifier": "totals"},
                                        "[90Sr]X2": {"outputQualifier": "molalities"},
                                        "[137Cs]":   {"outputQualifier": "totals"},
                                        "[137Cs]X": {"outputQualifier": "molalities"},
                                        "[137Cs]Xa": {"outputQualifier": "molalities"},
                                        "[137Cs]Xb": {"outputQualifier": "molalities"},
                                    },
                       "expressions":
                        { "[90Sr]" :  "'[90Sr]X2'/'[90Sr]' * porosity / bulkDensity ",
                          "[137Cs]" :  "('[137Cs]X' + '[137Cs]Xa' + '[137Cs]Xb')/'[137Cs]'* porosity/ bulkDensity"},
                       "variables" : 
                            {"porosity" : 0.2,
                             "bulkDensity" : 2600.,
                             "molarWeightCs" : 132.9,
                             "molarWeightSr" : 87.62}
                       }
                     }
             }
     },
  #===============================================================================
  # general time and periode information
  #===============================================================================
  "timeStepInfo" : {"iniTime" : 0,
                    "endTime" : 2.50E+04,
                    "unit" : "y"},
  #===============================================================================
  # Marfa Output
  #===============================================================================
  "MarfaOutput" : {"Kd" : {"[90Sr]"  : {"numberOfBins" : 10},
                           "[137Cs]" : {"numberOfBins" : 10}},
                   "streamLine" : "STR1",
				   "timeUnit" : "y",
                   "rockType" : "CPM1",
                   "outputFiles" : {"kdbins" : "kdbins.dat",
                                    "kdhistory" : "kdhistory.dat"}
                  }
}